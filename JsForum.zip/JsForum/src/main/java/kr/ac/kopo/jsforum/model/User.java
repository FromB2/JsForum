package kr.ac.kopo.jsforum.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class User {
    private String id;

    private String pw;

    private String name;

}

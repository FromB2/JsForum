package kr.ac.kopo.jsforum.model;

import lombok.Getter;
import lombok.Setter;

import java.util.Date;
@Getter
@Setter
public class Free {
	private int num;
	private String name;
	private Date pubDate;
	private String Id;
	private String username;
	private String contents;
	
	

}

package kr.ac.kopo.jsforum.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Region {
    private int num;
    private String name;
    private String info;
    private String reigonImg;


}
